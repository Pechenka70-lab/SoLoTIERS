from __future__ import annotations

import hmac
import os
import re
import secrets
import sqlite3
import threading
import time
from contextlib import closing
from datetime import datetime, timedelta
from functools import wraps
from typing import Any, Callable
from zoneinfo import ZoneInfo

from flask import Flask, g, jsonify, request, session, send_from_directory
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash, generate_password_hash

from database import (
    KITS,
    TIERS,
    TIER_POINTS,
    connect,
    initialize_database,
    nickname_sort_key,
    seed_admin,
    serialize_player,
)

API_PREFIX = "/solotiers-api"
MOSCOW = ZoneInfo("Europe/Moscow")
TIER_ORDER = {tier: index for index, tier in enumerate(TIERS)}
NICKNAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{3,16}$")
USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{3,24}$")

SECRET_KEY = os.environ.get("SECRET_KEY") or os.environ.get("SESSION_SECRET")
if not SECRET_KEY:
    raise RuntimeError("Add SECRET_KEY in Replit Secrets before starting SoLoTIERS.")

STATIC_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))
app = Flask(__name__)
app.config.update(
    SECRET_KEY=SECRET_KEY,
    MAX_CONTENT_LENGTH=32 * 1024,
    SESSION_COOKIE_NAME="solotiers_session",
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=(
        os.environ.get("REPLIT_ENVIRONMENT") == "production"
        or os.environ.get("NODE_ENV") == "production"
    ),
    PERMANENT_SESSION_LIFETIME=timedelta(days=14),
)

initialize_database()

admin_username = os.environ.get("ADMIN_USERNAME", "").strip()
admin_password = os.environ.get("ADMIN_PASSWORD", "")
if admin_username and admin_password:
    if (
        not 1 <= len(admin_username) <= 64
        or any(ord(character) < 32 for character in admin_username)
        or len(admin_password) > 1024
    ):
        raise RuntimeError(
            "ADMIN_USERNAME must be 1-64 printable characters and ADMIN_PASSWORD "
            "must be a non-empty value of at most 1024 characters."
        )
    seed_admin(
        admin_username,
        generate_password_hash(admin_password),
        datetime.now(MOSCOW).isoformat(),
    )


def current_language() -> str:
    saved_language = session.get("language")
    if saved_language in ("ru", "en"):
        return saved_language
    accepted = request.headers.get("Accept-Language", "").lower()
    return "en" if accepted.startswith("en") else "ru"


ERROR_MESSAGES: dict[str, tuple[str, str]] = {
    "invalid_json": ("Некорректный запрос.", "Invalid request body."),
    "csrf": ("Обновите страницу и повторите действие.", "Refresh the page and try again."),
    "unauthorized": ("Войдите в аккаунт, чтобы продолжить.", "Sign in to continue."),
    "forbidden": ("Недостаточно прав для этого действия.", "You do not have permission to do this."),
    "not_found": ("Запись не найдена.", "The requested record was not found."),
    "invalid_nickname": ("Ник должен содержать 3–16 допустимых символов Minecraft.", "Minecraft nicknames must contain 3–16 valid characters."),
    "invalid_username": ("Имя аккаунта должно содержать 3–24 буквы, цифры или подчёркивания.", "Account names must contain 3–24 letters, numbers, or underscores."),
    "invalid_password": ("Пароль должен содержать не менее 10 символов.", "Passwords must be at least 10 characters long."),
    "duplicate_username": ("Такое имя аккаунта уже занято.", "That account name is already taken."),
    "duplicate_nickname": ("Игрок с таким ником уже существует.", "A player with that nickname already exists."),
    "invalid_language": ("Выберите русский или английский язык.", "Choose Russian or English."),
    "invalid_kit": ("Неизвестный кит.", "Unknown kit."),
    "invalid_tier": ("Неизвестный тир.", "Unknown tier."),
    "invalid_role": ("Неизвестная роль.", "Unknown role."),
    "invalid_settings": ("Проверьте настройки и попробуйте снова.", "Check the settings and try again."),
    "invalid_discord_id": ("Некорректный Discord ID.", "Invalid Discord ID."),
    "linked_nickname": ("Для смены ника игрока с Discord-связью требуется повторная верификация.", "A Discord-linked player's nickname can only be changed after re-verification."),
    "nickname_mismatch": ("Ник не совпадает с привязанным аккаунтом. Сначала выполните повторную верификацию.", "The nickname does not match the linked account. Re-verify the player first."),
    "duplicate_discord": ("Этот Discord ID уже привязан к другому игроку.", "That Discord ID is already linked to another player."),
    "invalid_datetime": ("Укажите дату и время с часовым поясом.", "Provide a date and time that includes a timezone."),
    "player_not_found": ("Игрок с таким ником не найден.", "No player with that nickname was found."),
    "discord_mapping_mismatch": ("Discord ID не совпадает с привязкой игрока.", "The Discord ID does not match the player's link."),
    "demo_result_forbidden": ("Нельзя записывать результат для DEMO-профиля.", "Results cannot be written to a DEMO profile."),
    "invalid_credentials": ("Неверное имя аккаунта или пароль.", "Incorrect account name or password."),
    "rate_limited": ("Слишком много попыток входа. Подождите минуту.", "Too many sign-in attempts. Wait a minute."),
    "last_admin": ("Нельзя удалить или понизить последнего администратора.", "The last administrator cannot be removed or demoted."),
    "missing_discord_key": ("Защищённый Discord API пока не настроен.", "The protected Discord API is not configured yet."),
    "invalid_api_key": ("Неверный ключ API.", "Invalid API key."),
    "missing_mapping": ("Сначала привяжите игрока через верификацию Discord.", "Link the player through Discord verification first."),
    "missing_tester": ("Проверяющий не найден в списке тестеров.", "The reviewer is not in the tester list."),
}


def api_error(code: str, status: int = 400):
    translations = ERROR_MESSAGES.get(code)
    if translations is None:
        text = code
    else:
        text = translations[0] if current_language() == "ru" else translations[1]
    return jsonify({"error": text}), status


def json_body() -> dict[str, Any] | None:
    payload = request.get_json(silent=True)
    return payload if isinstance(payload, dict) else None


def moscow_now() -> str:
    return datetime.now(MOSCOW).isoformat()


def parse_moscow_datetime(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip() or len(value) > 64:
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.astimezone(MOSCOW).isoformat()


def valid_nickname(value: Any) -> bool:
    return isinstance(value, str) and NICKNAME_PATTERN.fullmatch(value) is not None


def valid_discord_id(value: Any, optional: bool = False) -> bool:
    if optional and value is None:
        return True
    return isinstance(value, str) and value.isdigit() and 1 <= len(value) <= 32


def get_current_user() -> sqlite3.Row | None:
    if hasattr(g, "solotiers_user"):
        return g.solotiers_user
    user_id = session.get("user_id")
    if not isinstance(user_id, int):
        g.solotiers_user = None
        return None
    with closing(connect()) as db:
        user = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    g.solotiers_user = user
    if user is not None:
        session["language"] = user["language"]
    return user


def public_user(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "username": row["username"],
        "role": row["role"],
        "language": row["language"],
        "createdAt": row["created_at"],
        "discordId": row["discord_id"],
    }


def new_session_for(user: sqlite3.Row) -> dict[str, Any]:
    session.clear()
    session.permanent = True
    session["user_id"] = user["id"]
    session["language"] = user["language"]
    session["csrf_token"] = secrets.token_urlsafe(32)
    g.solotiers_user = user
    return {"user": public_user(user), "csrfToken": session["csrf_token"]}


def session_envelope() -> dict[str, Any]:
    csrf_token = session.get("csrf_token")
    if not isinstance(csrf_token, str):
        csrf_token = secrets.token_urlsafe(32)
        session["csrf_token"] = csrf_token
    user = get_current_user()
    return {
        "user": public_user(user) if user is not None else None,
        "csrfToken": csrf_token,
    }


def request_has_valid_csrf() -> bool:
    expected = session.get("csrf_token")
    provided = request.headers.get("X-CSRF-Token")
    return (
        isinstance(expected, str)
        and isinstance(provided, str)
        and hmac.compare_digest(expected, provided)
    )


@app.before_request
def enforce_csrf() -> Any:
    if (
        request.path.startswith(API_PREFIX)
        and request.method in {"POST", "PUT", "PATCH", "DELETE"}
        and "/discord/" not in request.path
        and not request_has_valid_csrf()
    ):
        return api_error("csrf", 403)
    return None


def login_required(handler: Callable):
    @wraps(handler)
    def wrapped(*args: Any, **kwargs: Any):
        if get_current_user() is None:
            return api_error("unauthorized", 401)
        return handler(*args, **kwargs)

    return wrapped


def admin_required(handler: Callable):
    @wraps(handler)
    def wrapped(*args: Any, **kwargs: Any):
        user = get_current_user()
        if user is None:
            return api_error("unauthorized", 401)
        if user["role"] != "admin":
            return api_error("forbidden", 403)
        return handler(*args, **kwargs)

    return wrapped


def discord_key_required(handler: Callable):
    @wraps(handler)
    def wrapped(*args: Any, **kwargs: Any):
        # Keep the old misspelled key as a migration fallback; the correctly
        # named Replit Secret takes precedence and neither value is logged.
        expected = os.environ.get("DISCORD_API_KEY") or os.environ.get("DISCORD_APY_KEY")
        if not expected:
            return discord_api_error("missing_discord_key", 503)
        supplied = request.headers.get("X-API-Key", "")
        if not supplied or not hmac.compare_digest(expected, supplied):
            return discord_api_error("invalid_api_key", 401)
        return handler(*args, **kwargs)

    return wrapped


def discord_api_error(code: str, status: int = 400):
    translations = ERROR_MESSAGES.get(code)
    if translations is None:
        message = code
    else:
        message = translations[0] if current_language() == "ru" else translations[1]
    return jsonify(
        {
            "success": False,
            "error": {
                "code": code,
                "message": message,
            },
        }
    ), status


def _all_players(db: sqlite3.Connection, search: str = "") -> list[dict[str, Any]]:
    if search:
        rows = db.execute(
            "SELECT * FROM players WHERE nickname LIKE ? ESCAPE '\\'",
            (f"%{search.replace('%', '\\%').replace('_', '\\_')}%",),
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM players").fetchall()
    players = [serialize_player(row, db) for row in rows]
    return sorted(players, key=lambda player: nickname_sort_key(player["nickname"]))


def _ranked_players(db: sqlite3.Connection) -> list[dict[str, Any]]:
    players = _all_players(db)
    players.sort(
        key=lambda player: (
            -player["points"],
            nickname_sort_key(player["nickname"]),
        )
    )
    for rank, player in enumerate(players, start=1):
        player["rank"] = rank
    return players


def _history_payload(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "playerId": row["player_id"],
        "nickname": row["nickname"],
        "kit": row["kit"],
        "oldTier": row["old_tier"],
        "newTier": row["new_tier"],
        "reviewer": row["reviewer"],
        "testerDiscordId": row["tester_discord_id"],
        "occurredAt": row["occurred_at"],
    }


def _history_for_player(db: sqlite3.Connection, player_id: int) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        SELECT * FROM history
        WHERE player_id = ?
        ORDER BY occurred_at DESC, id DESC
        LIMIT 300
        """,
        (player_id,),
    ).fetchall()
    return [_history_payload(row) for row in rows]


def _write_tier_change(
    db: sqlite3.Connection,
    player: sqlite3.Row,
    kit: str,
    new_tier: str,
    reviewer: str,
    occurred_at: str,
    tester_discord_id: str | None = None,
) -> str:
    previous = db.execute(
        "SELECT tier FROM current_tiers WHERE player_id = ? AND kit = ?",
        (player["id"], kit),
    ).fetchone()
    old_tier = previous["tier"] if previous is not None else "NA"
    db.execute(
        """
        INSERT INTO current_tiers (player_id, kit, tier)
        VALUES (?, ?, ?)
        ON CONFLICT(player_id, kit) DO UPDATE SET tier = excluded.tier
        """,
        (player["id"], kit, new_tier),
    )
    db.execute(
        """
        INSERT INTO history
            (player_id, nickname, kit, old_tier, new_tier, reviewer,
             tester_discord_id, occurred_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            player["id"],
            player["nickname"],
            kit,
            old_tier,
            new_tier,
            reviewer,
            tester_discord_id,
            occurred_at,
        ),
    )
    return old_tier


_login_attempts: dict[str, list[float]] = {}
_login_attempts_lock = threading.Lock()


def _too_many_login_attempts(username: str) -> bool:
    now = time.monotonic()
    key = username.casefold()
    with _login_attempts_lock:
        recent = [attempt for attempt in _login_attempts.get(key, []) if now - attempt < 60]
        _login_attempts[key] = recent
        return len(recent) >= 8


def _record_login_failure(username: str) -> None:
    with _login_attempts_lock:
        _login_attempts.setdefault(username.casefold(), []).append(time.monotonic())


def _clear_login_failures(username: str) -> None:
    with _login_attempts_lock:
        _login_attempts.pop(username.casefold(), None)


@app.get(f"{API_PREFIX}/healthz")
def health():
    return jsonify({"status": "ok"})


@app.get(f"{API_PREFIX}/overview")
def overview():
    with closing(connect()) as db:
        ranked = _ranked_players(db)
        tester_count = db.execute("SELECT COUNT(*) FROM testers").fetchone()[0]
        test_count = db.execute("SELECT COUNT(*) FROM history").fetchone()[0]
        demo_count = db.execute(
            "SELECT COUNT(*) FROM players WHERE is_demo = 1"
        ).fetchone()[0]
        recent_rows = db.execute(
            "SELECT * FROM history ORDER BY occurred_at DESC, id DESC LIMIT 6"
        ).fetchall()
        recent = [_history_payload(row) for row in recent_rows]
        real_players = [player for player in ranked if not player["isDemo"]]
        return jsonify(
            {
                "playerCount": len(real_players),
                "testerCount": tester_count,
                "testCount": test_count,
                "demoCount": demo_count,
                "topPlayers": real_players[:5],
                "recentHistory": recent,
            }
        )


@app.get(f"{API_PREFIX}/leaderboards/overall")
def overall_leaderboard():
    with closing(connect()) as db:
        return jsonify(_ranked_players(db))


@app.get(f"{API_PREFIX}/leaderboards/kits/<kit>")
def kit_leaderboard(kit: str):
    if kit not in KITS:
        return api_error("invalid_kit", 404)
    with closing(connect()) as db:
        players = _all_players(db)
        players = [
            player
            for player in players
            if player["tiers"].get(kit, "NA") != "NA"
        ]
        players.sort(
            key=lambda player: (
                TIER_ORDER[player["tiers"][kit]],
                nickname_sort_key(player["nickname"]),
            )
        )
        for rank, player in enumerate(players, start=1):
            player["rank"] = rank
        buckets = [
            {
                "tier": tier,
                "players": [
                    player for player in players if player["tiers"][kit] == tier
                ],
            }
            for tier in TIERS
            if tier != "NA"
        ]
        return jsonify(
            {
                "kit": kit,
                "tiers": buckets,
                "totalPlayers": sum(1 for player in players if not player["isDemo"]),
            }
        )


@app.get(f"{API_PREFIX}/players")
def list_players():
    search = request.args.get("search", "", type=str).strip()
    if len(search) > 32:
        return api_error("invalid_nickname", 400)
    with closing(connect()) as db:
        return jsonify(_all_players(db, search))


@app.get(f"{API_PREFIX}/players/<int:player_id>")
def get_player(player_id: int):
    with closing(connect()) as db:
        row = db.execute("SELECT * FROM players WHERE id = ?", (player_id,)).fetchone()
        if row is None:
            return api_error("not_found", 404)
        return jsonify(serialize_player(row, db))


@app.get(f"{API_PREFIX}/players/<int:player_id>/history")
def get_player_history(player_id: int):
    with closing(connect()) as db:
        return jsonify(_history_for_player(db, player_id))


@app.get(f"{API_PREFIX}/testers")
def list_testers():
    current_user = get_current_user()
    can_view_discord_ids = current_user is not None and current_user["role"] == "admin"
    with closing(connect()) as db:
        rows = db.execute(
            """
            SELECT users.id, users.username, testers.display_name, testers.discord_id
            FROM testers JOIN users ON users.id = testers.user_id
            ORDER BY users.username COLLATE NOCASE
            """
        ).fetchall()
        return jsonify(
            [
                {
                    "id": row["id"],
                    "username": row["username"],
                    "displayName": row["display_name"],
                    "discordId": row["discord_id"] if can_view_discord_ids else None,
                }
                for row in rows
            ]
        )


@app.get(f"{API_PREFIX}/auth/session")
def get_session():
    return jsonify(session_envelope())


@app.post(f"{API_PREFIX}/auth/register")
def register_account():
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    username = data.get("username")
    password = data.get("password")
    language = data.get("language", "ru")
    if not isinstance(username, str) or not USERNAME_PATTERN.fullmatch(username):
        return api_error("invalid_username", 400)
    if not isinstance(password, str) or len(password) < 10 or len(password) > 128:
        return api_error("invalid_password", 400)
    if language not in ("ru", "en"):
        return api_error("invalid_language", 400)
    with closing(connect()) as db:
        try:
            cursor = db.execute(
                """
                INSERT INTO users (username, password_hash, role, language, created_at)
                VALUES (?, ?, 'user', ?, ?)
                """,
                (
                    username,
                    generate_password_hash(password),
                    language,
                    moscow_now(),
                ),
            )
            user = db.execute(
                "SELECT * FROM users WHERE id = ?", (cursor.lastrowid,)
            ).fetchone()
            db.commit()
        except sqlite3.IntegrityError:
            db.rollback()
            return api_error("duplicate_username", 409)
    return jsonify(new_session_for(user)), 201


@app.post(f"{API_PREFIX}/auth/login")
def login_account():
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    username = data.get("username")
    password = data.get("password")
    if not isinstance(username, str) or not isinstance(password, str):
        return api_error("invalid_credentials", 401)
    if _too_many_login_attempts(username):
        return api_error("rate_limited", 429)
    with closing(connect()) as db:
        user = db.execute(
            "SELECT * FROM users WHERE username = ? COLLATE NOCASE",
            (username.strip(),),
        ).fetchone()
    if user is None or not check_password_hash(user["password_hash"], password):
        _record_login_failure(username)
        return api_error("invalid_credentials", 401)
    _clear_login_failures(username)
    return jsonify(new_session_for(user))


@app.post(f"{API_PREFIX}/auth/logout")
def logout_account():
    session.clear()
    return jsonify({"message": "Signed out"})


@app.patch(f"{API_PREFIX}/auth/language")
@login_required
def update_language():
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    language = data.get("language")
    if language not in ("ru", "en"):
        return api_error("invalid_language", 400)
    user = get_current_user()
    with closing(connect()) as db:
        db.execute("UPDATE users SET language = ? WHERE id = ?", (language, user["id"]))
        db.commit()
        refreshed = db.execute(
            "SELECT * FROM users WHERE id = ?", (user["id"],)
        ).fetchone()
    session["language"] = language
    g.solotiers_user = refreshed
    return jsonify(session_envelope())


@app.post(f"{API_PREFIX}/admin/players")
@admin_required
def create_player():
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    nickname = data.get("nickname")
    is_demo = data.get("isDemo", False)
    if not valid_nickname(nickname):
        return api_error("invalid_nickname", 400)
    if not isinstance(is_demo, bool):
        return api_error("invalid_json", 400)
    if data.get("discordId") not in (None, ""):
        return api_error("linked_nickname", 403)
    with closing(connect()) as db:
        try:
            cursor = db.execute(
                "INSERT INTO players (nickname, is_demo, created_at) VALUES (?, ?, ?)",
                (nickname, int(is_demo), moscow_now()),
            )
            player_id = cursor.lastrowid
            db.executemany(
                "INSERT INTO current_tiers (player_id, kit, tier) VALUES (?, ?, 'NA')",
                [(player_id, kit) for kit in KITS],
            )
            db.commit()
        except sqlite3.IntegrityError:
            db.rollback()
            return api_error("duplicate_nickname", 409)
        player = db.execute(
            "SELECT * FROM players WHERE id = ?", (player_id,)
        ).fetchone()
        return jsonify(serialize_player(player, db)), 201


@app.patch(f"{API_PREFIX}/admin/players/<int:player_id>")
@admin_required
def update_player(player_id: int):
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    if "discordId" in data and data["discordId"] not in (None, ""):
        return api_error("linked_nickname", 403)
    nickname = data.get("nickname")
    if nickname is not None and not valid_nickname(nickname):
        return api_error("invalid_nickname", 400)
    with closing(connect()) as db:
        player = db.execute("SELECT * FROM players WHERE id = ?", (player_id,)).fetchone()
        if player is None:
            return api_error("not_found", 404)
        if nickname and nickname.casefold() != player["nickname"].casefold():
            if player["discord_id"]:
                return api_error("linked_nickname", 409)
            try:
                db.execute(
                    "UPDATE players SET nickname = ? WHERE id = ?",
                    (nickname, player_id),
                )
                db.execute(
                    "UPDATE history SET nickname = ? WHERE player_id = ?",
                    (nickname, player_id),
                )
                db.commit()
            except sqlite3.IntegrityError:
                db.rollback()
                return api_error("duplicate_nickname", 409)
        updated = db.execute(
            "SELECT * FROM players WHERE id = ?", (player_id,)
        ).fetchone()
        return jsonify(serialize_player(updated, db))


@app.delete(f"{API_PREFIX}/admin/players/<int:player_id>")
@admin_required
def delete_player(player_id: int):
    with closing(connect()) as db:
        player = db.execute("SELECT id FROM players WHERE id = ?", (player_id,)).fetchone()
        if player is None:
            return api_error("not_found", 404)
        db.execute("DELETE FROM players WHERE id = ?", (player_id,))
        db.commit()
    return jsonify({"message": "Player removed"})


@app.put(f"{API_PREFIX}/admin/players/<int:player_id>/tiers/<kit>")
@admin_required
def change_player_tier(player_id: int, kit: str):
    if kit not in KITS:
        return api_error("invalid_kit", 404)
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    tier = data.get("tier")
    if tier not in TIERS:
        return api_error("invalid_tier", 400)
    user = get_current_user()
    with closing(connect()) as db:
        player = db.execute(
            "SELECT * FROM players WHERE id = ?", (player_id,)
        ).fetchone()
        if player is None:
            return api_error("not_found", 404)
        _write_tier_change(
            db,
            player,
            kit,
            tier,
            user["username"],
            moscow_now(),
        )
        db.commit()
        updated = db.execute(
            "SELECT * FROM players WHERE id = ?", (player_id,)
        ).fetchone()
        return jsonify(serialize_player(updated, db))


@app.get(f"{API_PREFIX}/admin/users")
@admin_required
def list_admin_users():
    with closing(connect()) as db:
        rows = db.execute(
            "SELECT * FROM users ORDER BY username COLLATE NOCASE"
        ).fetchall()
        return jsonify([public_user(row) for row in rows])


def _admin_count(db: sqlite3.Connection) -> int:
    return db.execute(
        "SELECT COUNT(*) FROM users WHERE role = 'admin'"
    ).fetchone()[0]


@app.patch(f"{API_PREFIX}/admin/users/<int:user_id>/role")
@admin_required
def update_user_role(user_id: int):
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    role = data.get("role")
    if role not in ("admin", "tester", "user"):
        return api_error("invalid_role", 400)
    with closing(connect()) as db:
        target = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if target is None:
            return api_error("not_found", 404)
        if target["role"] == "admin" and role != "admin" and _admin_count(db) <= 1:
            return api_error("last_admin", 409)
        db.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
        if role == "tester":
            db.execute(
                """
                INSERT INTO testers (user_id, display_name, discord_id)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET display_name = excluded.display_name
                """,
                (user_id, target["username"], target["discord_id"]),
            )
        else:
            db.execute("DELETE FROM testers WHERE user_id = ?", (user_id,))
        db.commit()
        updated = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return jsonify(public_user(updated))


@app.post(f"{API_PREFIX}/admin/testers")
@admin_required
def add_tester():
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    user_id = data.get("userId")
    discord_id = data.get("discordId")
    if not isinstance(user_id, int) or user_id <= 0:
        return api_error("invalid_json", 400)
    if not valid_discord_id(discord_id, optional=True):
        return api_error("invalid_discord_id", 400)
    with closing(connect()) as db:
        target = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if target is None:
            return api_error("not_found", 404)
        if target["role"] == "admin" and _admin_count(db) <= 1:
            return api_error("last_admin", 409)
        try:
            db.execute(
                "UPDATE users SET role = 'tester', discord_id = ? WHERE id = ?",
                (discord_id, user_id),
            )
            db.execute(
                """
                INSERT INTO testers (user_id, display_name, discord_id)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    display_name = excluded.display_name,
                    discord_id = excluded.discord_id
                """,
                (user_id, target["username"], discord_id),
            )
            db.commit()
        except sqlite3.IntegrityError:
            db.rollback()
            return api_error("duplicate_discord", 409)
        updated = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return jsonify(public_user(updated)), 201


@app.delete(f"{API_PREFIX}/admin/testers/<int:user_id>")
@admin_required
def remove_tester(user_id: int):
    with closing(connect()) as db:
        target = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if target is None or target["role"] != "tester":
            return api_error("not_found", 404)
        db.execute("DELETE FROM testers WHERE user_id = ?", (user_id,))
        db.execute("UPDATE users SET role = 'user' WHERE id = ?", (user_id,))
        db.commit()
    return jsonify({"message": "Tester removed"})


@app.get(f"{API_PREFIX}/admin/settings")
@admin_required
def get_settings():
    with closing(connect()) as db:
        settings = {
            row["setting_key"]: row["setting_value"]
            for row in db.execute("SELECT setting_key, setting_value FROM site_settings")
        }
    return jsonify(
        {
            "siteName": settings.get("site_name", "SoLoTIERS"),
            "defaultLanguage": settings.get("default_language", "ru"),
        }
    )


@app.patch(f"{API_PREFIX}/admin/settings")
@admin_required
def update_settings():
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    site_name = data.get("siteName")
    language = data.get("defaultLanguage")
    if (
        not isinstance(site_name, str)
        or not site_name.strip()
        or len(site_name.strip()) > 48
        or language not in ("ru", "en")
    ):
        return api_error("invalid_settings", 400)
    with closing(connect()) as db:
        db.executemany(
            """
            INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?)
            ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value
            """,
            [
                ("site_name", site_name.strip()),
                ("default_language", language),
            ],
        )
        db.commit()
    return jsonify({"siteName": site_name.strip(), "defaultLanguage": language})


@app.post(f"{API_PREFIX}/discord/results")
@discord_key_required
def submit_discord_result():
    data = json_body()
    if data is None:
        return discord_api_error("invalid_json", 400)

    # Accept the previous camelCase contract during bot rollout while making
    # the documented snake_case fields canonical.
    discord_id = data.get("discord_user_id", data.get("discordId"))
    minecraft_nickname = data.get(
        "minecraft_nickname", data.get("minecraftNickname")
    )
    kit = data.get("kit")
    tier = data.get("new_tier", data.get("tier"))
    reviewer_discord_id = data.get(
        "tester_discord_id", data.get("reviewerDiscordId")
    )
    occurred_at = parse_moscow_datetime(
        data.get("tested_at", data.get("occurredAt"))
    )
    if not valid_discord_id(discord_id) or not valid_discord_id(reviewer_discord_id):
        return discord_api_error("invalid_discord_id", 400)
    if not valid_nickname(minecraft_nickname):
        return discord_api_error("invalid_nickname", 400)
    if kit not in KITS:
        return discord_api_error("invalid_kit", 400)
    if tier not in TIERS:
        return discord_api_error("invalid_tier", 400)
    if occurred_at is None:
        return discord_api_error("invalid_datetime", 400)

    with closing(connect()) as db:
        player = db.execute(
            "SELECT * FROM players WHERE discord_id = ?", (discord_id,)
        ).fetchone()
        if player is None:
            nickname_match = db.execute(
                "SELECT * FROM players WHERE nickname = ? COLLATE NOCASE",
                (minecraft_nickname,),
            ).fetchone()
            if nickname_match is None:
                return discord_api_error("player_not_found", 404)
            if nickname_match["discord_id"] is None:
                return discord_api_error("missing_mapping", 409)
            return discord_api_error("discord_mapping_mismatch", 409)
        if player["nickname"].casefold() != minecraft_nickname.casefold():
            return discord_api_error("nickname_mismatch", 409)
        if player["is_demo"]:
            return discord_api_error("demo_result_forbidden", 409)

        tester = db.execute(
            "SELECT display_name FROM testers WHERE discord_id = ?",
            (reviewer_discord_id,),
        ).fetchone()
        if tester is None:
            return discord_api_error("missing_tester", 403)

        previous_tier = _write_tier_change(
            db,
            player,
            kit,
            tier,
            tester["display_name"],
            occurred_at,
            reviewer_discord_id,
        )
        db.commit()
        updated = db.execute(
            "SELECT * FROM players WHERE id = ?", (player["id"],)
        ).fetchone()
        updated_player = serialize_player(updated, db)
        return jsonify(
            {
                "success": True,
                "discord_user_id": discord_id,
                "minecraft_nickname": updated_player["nickname"],
                "kit": kit,
                "previous_tier": previous_tier,
                "new_tier": tier,
                "tester_discord_id": reviewer_discord_id,
                "tested_at": occurred_at,
                "total_points": updated_player["points"],
                "player": updated_player,
            }
        )


@app.get(f"{API_PREFIX}/discord/connection-test")
@discord_key_required
def discord_connection_test():
    return jsonify(
        {
            "success": True,
            "service": "SoLoTIERS",
            "mode": "connection_test",
            "writes_data": False,
        }
    )


@app.post(f"{API_PREFIX}/discord/verify")
@discord_key_required
def verify_discord_player():
    data = json_body()
    if data is None:
        return api_error("invalid_json", 400)
    discord_id = data.get("discordId")
    nickname = data.get("minecraftNickname")
    if not valid_discord_id(discord_id):
        return api_error("invalid_discord_id", 400)
    if not valid_nickname(nickname):
        return api_error("invalid_nickname", 400)
    with closing(connect()) as db:
        player = db.execute(
            "SELECT * FROM players WHERE discord_id = ?", (discord_id,)
        ).fetchone()
        collision = db.execute(
            "SELECT * FROM players WHERE nickname = ? COLLATE NOCASE",
            (nickname,),
        ).fetchone()
        if collision is not None and (
            player is None or collision["id"] != player["id"]
        ):
            return api_error("duplicate_nickname", 409)
        if player is None:
            player = collision
            if player is None:
                cursor = db.execute(
                    """
                    INSERT INTO players (nickname, discord_id, is_demo, created_at)
                    VALUES (?, ?, 0, ?)
                    """,
                    (nickname, discord_id, moscow_now()),
                )
                player_id = cursor.lastrowid
                db.executemany(
                    "INSERT INTO current_tiers (player_id, kit, tier) VALUES (?, ?, 'NA')",
                    [(player_id, kit) for kit in KITS],
                )
            else:
                db.execute(
                    "UPDATE players SET discord_id = ?, is_demo = 0 WHERE id = ?",
                    (discord_id, player["id"]),
                )
                player_id = player["id"]
        else:
            db.execute(
                "UPDATE players SET nickname = ?, is_demo = 0 WHERE id = ?",
                (nickname, player["id"]),
            )
            db.execute(
                "UPDATE history SET nickname = ? WHERE player_id = ?",
                (nickname, player["id"]),
            )
            player_id = player["id"]
        db.commit()
        updated = db.execute(
            "SELECT * FROM players WHERE id = ?", (player_id,)
        ).fetchone()
        return jsonify(serialize_player(updated, db))


@app.errorhandler(HTTPException)
def handle_http_error(error: HTTPException):
    return api_error("not_found" if error.code == 404 else error.name, error.code or 500)


@app.errorhandler(Exception)
def handle_unexpected_error(error: Exception):
    app.logger.exception("Unhandled SoLoTIERS API error")
    message = (
        "Не удалось выполнить запрос."
        if current_language() == "ru"
        else "The request could not be completed."
    )
    return jsonify({"error": message}), 500



@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_frontend(path: str):
    # Keep API routes under /solotiers-api and serve the compiled React app
    # for normal pages and client-side routes.
    if path.startswith("solotiers-api/"):
        return api_error("not_found", 404)
    requested = os.path.join(STATIC_DIR, path) if path else os.path.join(STATIC_DIR, "index.html")
    if os.path.isfile(requested):
        return send_from_directory(STATIC_DIR, path or "index.html")
    return send_from_directory(STATIC_DIR, "index.html")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8082"))
    app.run(host="0.0.0.0", port=port, debug=False)
