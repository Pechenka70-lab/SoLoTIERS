from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from pathlib import Path
from typing import Any

KITS = (
    "Sword",
    "Mace",
    "Spearmace",
    "Op",
    "Cart",
    "Smp",
    "Nethpot",
    "Pot",
    "Axe",
    "DiaOp",
)
TIERS = ("HT1", "LT1", "HT2", "LT2", "HT3", "LT3", "HT4", "LT4", "HT5", "LT5", "NA")
TIER_POINTS = {
    "HT1": 60,
    "LT1": 45,
    "HT2": 30,
    "LT2": 20,
    "HT3": 10,
    "LT3": 6,
    "HT4": 4,
    "LT4": 3,
    "HT5": 2,
    "LT5": 1,
    "NA": 0,
}

DATABASE_PATH = Path(
    os.environ.get(
        "DATABASE_PATH",
        Path(__file__).resolve().parents[1] / "data" / "solotiers.sqlite3",
    )
)

DEMO_PLAYERS: tuple[tuple[str, dict[str, str]], ...] = (
    (
        "2DemoWolf",
        {
            "Sword": "HT2",
            "Mace": "LT2",
            "Spearmace": "HT3",
            "Op": "LT3",
            "Cart": "HT4",
            "Smp": "LT2",
            "Nethpot": "HT3",
            "Pot": "LT3",
            "Axe": "HT4",
            "DiaOp": "NA",
        },
    ),
    (
        "CraftDemo",
        {
            "Sword": "LT1",
            "Mace": "HT2",
            "Spearmace": "LT2",
            "Op": "HT3",
            "Cart": "LT3",
            "Smp": "HT2",
            "Nethpot": "LT2",
            "Pot": "HT3",
            "Axe": "LT3",
            "DiaOp": "HT4",
        },
    ),
    (
        "PvPPractice",
        {
            "Sword": "HT3",
            "Mace": "LT3",
            "Spearmace": "NA",
            "Op": "HT4",
            "Cart": "LT4",
            "Smp": "HT3",
            "Nethpot": "LT3",
            "Pot": "HT4",
            "Axe": "LT3",
            "DiaOp": "NA",
        },
    ),
    (
        "TierTrial",
        {
            "Sword": "LT4",
            "Mace": "HT4",
            "Spearmace": "LT4",
            "Op": "NA",
            "Cart": "HT5",
            "Smp": "LT4",
            "Nethpot": "HT4",
            "Pot": "LT4",
            "Axe": "HT5",
            "DiaOp": "LT5",
        },
    ),
)


def connect() -> sqlite3.Connection:
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")
    return connection


def initialize_database() -> None:
    with closing(connect()) as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user'
                    CHECK (role IN ('admin', 'tester', 'user')),
                language TEXT NOT NULL DEFAULT 'ru'
                    CHECK (language IN ('ru', 'en')),
                discord_id TEXT UNIQUE,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS testers (
                user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                display_name TEXT NOT NULL,
                discord_id TEXT UNIQUE
            );

            CREATE TABLE IF NOT EXISTS players (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nickname TEXT NOT NULL UNIQUE COLLATE NOCASE,
                discord_id TEXT UNIQUE,
                is_demo INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1)),
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS kits (
                name TEXT PRIMARY KEY,
                sort_order INTEGER NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS current_tiers (
                player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
                kit TEXT NOT NULL REFERENCES kits(name),
                tier TEXT NOT NULL
                    CHECK (tier IN ('HT1', 'LT1', 'HT2', 'LT2', 'HT3', 'LT3',
                                    'HT4', 'LT4', 'HT5', 'LT5', 'NA')),
                PRIMARY KEY (player_id, kit)
            );

            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                player_id INTEGER NOT NULL,
                nickname TEXT NOT NULL,
                kit TEXT NOT NULL,
                old_tier TEXT NOT NULL,
                new_tier TEXT NOT NULL,
                reviewer TEXT NOT NULL,
                tester_discord_id TEXT,
                occurred_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS history_player_time
                ON history (player_id, occurred_at DESC);
            CREATE INDEX IF NOT EXISTS history_kit_time
                ON history (kit, occurred_at DESC);

            CREATE TABLE IF NOT EXISTS site_settings (
                setting_key TEXT PRIMARY KEY,
                setting_value TEXT NOT NULL
            );
            """
        )
        history_columns = {
            row["name"] for row in db.execute("PRAGMA table_info(history)")
        }
        if "tester_discord_id" not in history_columns:
            db.execute("ALTER TABLE history ADD COLUMN tester_discord_id TEXT")
        db.executemany(
            "INSERT OR IGNORE INTO kits (name, sort_order) VALUES (?, ?)",
            [(kit, position) for position, kit in enumerate(KITS)],
        )
        db.execute(
            "INSERT OR IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)",
            ("site_name", "SoLoTIERS"),
        )
        db.execute(
            "INSERT OR IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)",
            ("default_language", "ru"),
        )

        demo_count = db.execute(
            "SELECT COUNT(*) FROM players WHERE is_demo = 1"
        ).fetchone()[0]
        if demo_count == 0:
            from datetime import datetime
            from zoneinfo import ZoneInfo

            created_at = datetime.now(ZoneInfo("Europe/Moscow")).isoformat()
            for nickname, tiers in DEMO_PLAYERS:
                cursor = db.execute(
                    "INSERT INTO players (nickname, is_demo, created_at) VALUES (?, 1, ?)",
                    (nickname, created_at),
                )
                player_id = cursor.lastrowid
                db.executemany(
                    "INSERT INTO current_tiers (player_id, kit, tier) VALUES (?, ?, ?)",
                    [
                        (player_id, kit, tiers.get(kit, "NA"))
                        for kit in KITS
                    ],
                )
        db.commit()


def seed_admin(username: str, password_hash: str, created_at: str) -> None:
    with closing(connect()) as db:
        db.execute(
            """
            INSERT INTO users (username, password_hash, role, language, created_at)
            VALUES (?, ?, 'admin', 'ru', ?)
            ON CONFLICT(username) DO UPDATE SET
                password_hash = excluded.password_hash,
                role = 'admin'
            """,
            (username, password_hash, created_at),
        )
        db.commit()


def serialize_player(row: sqlite3.Row, db: sqlite3.Connection) -> dict[str, Any]:
    tier_rows = db.execute(
        "SELECT kit, tier FROM current_tiers WHERE player_id = ?",
        (row["id"],),
    ).fetchall()
    tiers = {kit: "NA" for kit in KITS}
    for tier_row in tier_rows:
        tiers[tier_row["kit"]] = tier_row["tier"]
    points = sum(TIER_POINTS[tier] for tier in tiers.values())
    from urllib.parse import quote

    nickname = row["nickname"]
    return {
        "id": row["id"],
        "nickname": nickname,
        "discordId": row["discord_id"],
        "points": points,
        "tiers": tiers,
        "isDemo": bool(row["is_demo"]),
        "createdAt": row["created_at"],
        "skinUrl": f"https://mc-heads.net/avatar/{quote(nickname, safe='')}/96",
    }


def nickname_sort_key(nickname: str) -> tuple[tuple[int, int], ...]:
    normalized = nickname.upper()
    key: list[tuple[int, int]] = []
    for char in normalized:
        if "0" <= char <= "9":
            key.append((0, ord(char) - ord("0")))
        elif "A" <= char <= "Z":
            key.append((1, ord(char) - ord("A")))
        else:
            key.append((2, ord(char)))
    return tuple(key)
