from __future__ import annotations

import os
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

BACKEND_DIR = Path(__file__).resolve().parent
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

_BOOTSTRAP_DIR = tempfile.TemporaryDirectory(prefix="solotiers-discord-tests-")
os.environ["DATABASE_PATH"] = str(Path(_BOOTSTRAP_DIR.name) / "bootstrap.sqlite3")
os.environ["SECRET_KEY"] = "test-only-session-secret"
os.environ["ADMIN_USERNAME"] = "test-admin"
os.environ["ADMIN_PASSWORD"] = "test-only-admin-password"
os.environ["DISCORD_API_KEY"] = "test-only-discord-key"

import database
from app import app


TEST_API_KEY = "test-only-discord-key"
PLAYER_DISCORD_ID = "111111111111111111"
TESTER_DISCORD_ID = "222222222222222222"


class DiscordApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.database_dir = tempfile.TemporaryDirectory(
            prefix="solotiers-discord-case-"
        )
        self.database_path = Path(self.database_dir.name) / "test.sqlite3"
        self.database_path_patch = patch.object(
            database, "DATABASE_PATH", self.database_path
        )
        self.database_path_patch.start()
        database.initialize_database()
        self.client = app.test_client()

        with closing(database.connect()) as db:
            player_cursor = db.execute(
                """
                INSERT INTO players (nickname, discord_id, is_demo, created_at)
                VALUES (?, ?, 0, '2026-11-05T12:00:00+03:00')
                """,
                ("TestPlayer", PLAYER_DISCORD_ID),
            )
            self.player_id = player_cursor.lastrowid
            db.executemany(
                "INSERT INTO current_tiers (player_id, kit, tier) VALUES (?, ?, 'NA')",
                [(self.player_id, kit) for kit in database.KITS],
            )
            db.execute(
                "UPDATE current_tiers SET tier = 'HT2' WHERE player_id = ? AND kit = 'Sword'",
                (self.player_id,),
            )
            db.execute(
                "UPDATE current_tiers SET tier = 'LT5' WHERE player_id = ? AND kit = 'Mace'",
                (self.player_id,),
            )
            user_cursor = db.execute(
                """
                INSERT INTO users
                    (username, password_hash, role, language, discord_id, created_at)
                VALUES ('test-reviewer', 'unused-test-hash', 'tester', 'ru', ?, ?)
                """,
                (TESTER_DISCORD_ID, "2026-11-05T12:00:00+03:00"),
            )
            db.execute(
                "INSERT INTO testers (user_id, display_name, discord_id) VALUES (?, ?, ?)",
                (user_cursor.lastrowid, "Test Reviewer", TESTER_DISCORD_ID),
            )
            db.commit()

        self.api_key_patch = patch.dict(
            os.environ, {"DISCORD_API_KEY": TEST_API_KEY}
        )
        self.api_key_patch.start()

    def tearDown(self) -> None:
        self.api_key_patch.stop()
        self.database_path_patch.stop()
        self.database_dir.cleanup()

    def headers(self, api_key: str = TEST_API_KEY) -> dict[str, str]:
        return {"X-API-Key": api_key}

    def valid_result(self) -> dict[str, str]:
        return {
            "discord_user_id": PLAYER_DISCORD_ID,
            "minecraft_nickname": "TestPlayer",
            "kit": "Mace",
            "new_tier": "HT1",
            "tester_discord_id": TESTER_DISCORD_ID,
            "tested_at": "2026-11-05T10:30:00Z",
        }

    def counts(self) -> tuple[int, int, int]:
        with closing(database.connect()) as db:
            players = db.execute("SELECT COUNT(*) FROM players").fetchone()[0]
            tiers = db.execute("SELECT COUNT(*) FROM current_tiers").fetchone()[0]
            history = db.execute("SELECT COUNT(*) FROM history").fetchone()[0]
        return players, tiers, history

    def test_connection_check_is_authenticated_and_read_only(self) -> None:
        before = self.counts()
        response = self.client.get(
            "/solotiers-api/discord/connection-test",
            headers=self.headers(),
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_json(),
            {
                "success": True,
                "service": "SoLoTIERS",
                "mode": "connection_test",
                "writes_data": False,
            },
        )
        self.assertEqual(self.counts(), before)

    def test_result_updates_only_requested_kit_and_writes_history(self) -> None:
        response = self.client.post(
            "/solotiers-api/discord/results",
            json=self.valid_result(),
            headers=self.headers(),
        )
        self.assertEqual(response.status_code, 200, response.get_json())
        body = response.get_json()
        self.assertTrue(body["success"])
        self.assertEqual(body["previous_tier"], "LT5")
        self.assertEqual(body["new_tier"], "HT1")
        self.assertEqual(body["tester_discord_id"], TESTER_DISCORD_ID)
        self.assertEqual(body["tested_at"], "2026-11-05T13:30:00+03:00")
        self.assertEqual(body["total_points"], 90)
        self.assertEqual(body["player"]["tiers"]["Mace"], "HT1")
        self.assertEqual(body["player"]["tiers"]["Sword"], "HT2")
        self.assertEqual(body["player"]["tiers"]["Axe"], "NA")

        with closing(database.connect()) as db:
            row = db.execute(
                """
                SELECT old_tier, new_tier, reviewer, tester_discord_id, occurred_at
                FROM history WHERE player_id = ?
                """,
                (self.player_id,),
            ).fetchone()
        self.assertEqual(row["old_tier"], "LT5")
        self.assertEqual(row["new_tier"], "HT1")
        self.assertEqual(row["reviewer"], "Test Reviewer")
        self.assertEqual(row["tester_discord_id"], TESTER_DISCORD_ID)
        self.assertEqual(row["occurred_at"], "2026-11-05T13:30:00+03:00")

    def test_invalid_fields_are_rejected_without_writing_history(self) -> None:
        invalid_values = (
            ("minecraft_nickname", "bad nick"),
            ("kit", "UnknownKit"),
            ("new_tier", "UNKNOWN"),
            ("tested_at", "2026-11-05T10:30:00"),
        )
        for field, value in invalid_values:
            with self.subTest(field=field):
                payload = self.valid_result()
                payload[field] = value
                response = self.client.post(
                    "/solotiers-api/discord/results",
                    json=payload,
                    headers=self.headers(),
                )
                self.assertEqual(response.status_code, 400)
                self.assertFalse(response.get_json()["success"])
        self.assertEqual(self.counts()[2], 0)

    def test_wrong_key_is_rejected(self) -> None:
        response = self.client.get(
            "/solotiers-api/discord/connection-test",
            headers=self.headers("wrong-test-key"),
        )
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.get_json()["error"]["code"], "invalid_api_key")

    def test_player_mapping_must_match_both_discord_id_and_nickname(self) -> None:
        payload = self.valid_result()
        payload["minecraft_nickname"] = "DifferentPlayer"
        response = self.client.post(
            "/solotiers-api/discord/results",
            json=payload,
            headers=self.headers(),
        )
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.get_json()["error"]["code"], "nickname_mismatch")
        self.assertEqual(self.counts()[2], 0)


if __name__ == "__main__":
    unittest.main()
