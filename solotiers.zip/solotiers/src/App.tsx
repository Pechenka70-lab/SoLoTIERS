import { useEffect, useRef, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Router as WouterRouter, Switch, useLocation, useRoute } from 'wouter';
import {
  Activity, ArrowDown, ArrowLeft, ArrowRight, BadgeCheck, ChevronDown, ChevronRight,
  CircleHelp, ClipboardList, Crown, ExternalLink, Gamepad2, Globe2, LoaderCircle,
  LogIn, LogOut, Menu, Search, ShieldCheck, Swords, UserRound, Users, X,
} from 'lucide-react';
import {
  Kit, Tier, useGetOverview, useGetOverallLeaderboard, useGetKitLeaderboard,
  useGetPlayer, useGetPlayerHistory, useListTesters, useGetSession, useRegisterAccount,
  useLoginAccount, useLogoutAccount, useUpdateLanguage, useListAdminUsers,
  useGetSettings, useCreatePlayer, useUpdatePlayer, useDeletePlayer,
  useChangePlayerTier, useUpdateUserRole, useAddTester, useRemoveTester,
  useUpdateSettings,
  getGetSessionQueryKey, getGetOverviewQueryKey, getGetOverallLeaderboardQueryKey,
  getGetKitLeaderboardQueryKey, getListPlayersQueryKey, getGetPlayerQueryKey,
  getGetPlayerHistoryQueryKey, getListTestersQueryKey, getListAdminUsersQueryKey,
  getGetSettingsQueryKey,
} from '@workspace/api-client-react';
import type { Language, Player, PlayerRanking, Kit as KitType, Tier as TierType } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import './index.css';

const queryClient = new QueryClient();
const kits = [Kit.Sword, Kit.Mace, Kit.Spearmace, Kit.Op, Kit.Cart, Kit.Smp, Kit.Nethpot, Kit.Pot, Kit.Axe, Kit.DiaOp] as KitType[];
const tiers = [Tier.HT1, Tier.LT1, Tier.HT2, Tier.LT2, Tier.HT3, Tier.LT3, Tier.HT4, Tier.LT4, Tier.HT5, Tier.LT5] as TierType[];
const tierWeight: Record<string, number> = Object.fromEntries([...tiers, Tier.NA].map((t, i) => [t, i]));
const ruCopy: Record<string, string> = {
  leaderboard: 'Рейтинг', testers: 'Тестеры', admin: 'Управление', login: 'Войти',
  logout: 'Выйти', players: 'Игроки', verified: 'Подтверждено', points: 'Очки',
  rank: 'Место', player: 'Игрок', kit: 'Режим', recent: 'Последние изменения',
  overview: 'Обзор сезона', totalPlayers: 'Игроков в рейтинге', tests: 'Проверок проведено',
  activeTesters: 'Активных тестеров', demoPlayers: 'Демо-записей', search: 'Найти игрока…',
  allPlayers: 'Общий рейтинг', tierDistribution: 'Распределение по тиру',
  noPlayers: 'В рейтинге пока нет игроков', demoSection: 'Демонстрационные записи', retry: 'Повторить', loading: 'Загружаем данные…',
  emptyHistory: 'История изменений пока пуста', history: 'История тиров', score: 'Рейтинг',
  signup: 'Создать аккаунт', username: 'Имя пользователя', password: 'Пароль',
  chooseAction: 'Выберите действие', create: 'Создать', save: 'Сохранить', cancel: 'Отмена',
  settings: 'Настройки сайта', users: 'Пользователи', addTester: 'Назначить тестера',
  recordResult: 'Записать результат', createPlayer: 'Добавить игрока', nickname: 'Minecraft-ник',
  discordId: 'Discord ID', reviewer: 'Discord ID проверяющего', occuredAt: 'Время результата',
  language: 'Язык интерфейса', siteName: 'Название сайта', defaultLanguage: 'Язык по умолчанию',
  submit: 'Отправить', noTesters: 'Список тестеров пуст', access: 'Доступ ограничен',
  adminOnly: 'Для управления войдите в аккаунт с правами администратора.',
  profile: 'Профиль игрока', testerDirectory: 'Команда проверяющих',
  protocol: 'Публичный рейтинг PvP', powered: 'Честная игра. Проверенные результаты.',
  noResults: 'Нет результатов', registered: 'Войти или зарегистрироваться', role: 'Роль', tier: 'Тир',
};
const enCopy: Record<string, string> = {
  leaderboard: 'Leaderboard', testers: 'Testers', admin: 'Management', login: 'Sign in',
  logout: 'Sign out', players: 'Players', verified: 'Verified', points: 'Points',
  rank: 'Rank', player: 'Player', kit: 'Kit', recent: 'Recent changes',
  overview: 'Season overview', totalPlayers: 'Ranked players', tests: 'Verified tests',
  activeTesters: 'Active testers', demoPlayers: 'Demo records', search: 'Find a player…',
  allPlayers: 'Overall standings', tierDistribution: 'Tier distribution',
  noPlayers: 'No players in the standings yet', demoSection: 'Demo records — separate from live rankings', retry: 'Try again', loading: 'Loading data…',
  emptyHistory: 'No tier changes yet', history: 'Tier history', score: 'Score',
  signup: 'Create account', username: 'Username', password: 'Password',
  chooseAction: 'Choose an action', create: 'Create', save: 'Save', cancel: 'Cancel',
  settings: 'Site settings', users: 'Users', addTester: 'Add tester',
  recordResult: 'Record result', createPlayer: 'Add player', nickname: 'Minecraft nickname',
  discordId: 'Discord ID', reviewer: 'Reviewer Discord ID', occuredAt: 'Result time',
  language: 'Interface language', siteName: 'Site name', defaultLanguage: 'Default language',
  submit: 'Submit', noTesters: 'No testers listed', access: 'Restricted access',
  adminOnly: 'Sign in with an administrator account to manage SoLoTIERS.',
  profile: 'Player profile', testerDirectory: 'Verification team',
  protocol: 'Public PvP rankings', powered: 'Fair play. Verified results.',
  noResults: 'No results', registered: 'Sign in or register', role: 'Role', tier: 'Tier',
};
const copy = (lang: Language, key: string) => (lang === 'ru' ? ruCopy[key] : enCopy[key]) || key;
const initials = (s: string) => s.slice(0, 2).toUpperCase();
const nickOrder = (a: string, b: string) => {
  const left = a.toUpperCase();
  const right = b.toUpperCase();
  for (let index = 0; index < Math.min(left.length, right.length); index += 1) {
    const leftChar = left[index];
    const rightChar = right[index];
    const rank = (char: string) => {
      if (char >= '0' && char <= '9') return [0, char.charCodeAt(0) - 48];
      if (char >= 'A' && char <= 'Z') return [1, char.charCodeAt(0) - 65];
      return [2, char.charCodeAt(0)];
    };
    const [leftClass, leftValue] = rank(leftChar);
    const [rightClass, rightValue] = rank(rightChar);
    if (leftClass !== rightClass) return leftClass - rightClass;
    if (leftValue !== rightValue) return leftValue - rightValue;
  }
  return left.length - right.length;
};
const formatDate = (date: string, lang: Language) => new Intl.DateTimeFormat(lang === 'ru' ? 'ru-RU' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(date));
const csrfRequest = (token?: string): { headers: Record<string, string> } => ({ headers: { 'X-CSRF-Token': token || '' } });

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><AppShell /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

function AppShell() {
  const session = useGetSession();
  const user = session.data?.user;
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('solotiers-language');
    return saved === 'en' || saved === 'ru' ? saved : 'ru';
  });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();
  const token = session.data?.csrfToken;
  useEffect(() => {
    if (user?.language) {
      setLang(user.language);
      localStorage.setItem('solotiers-language', user.language);
    }
  }, [user?.language]);
  const updateLanguage = useUpdateLanguage({ request: csrfRequest(token), mutation: {
    onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetSessionQueryKey() }),
  } });
  const changeLanguage = (next: Language) => {
    setLang(next);
    localStorage.setItem('solotiers-language', next);
    if (user) updateLanguage.mutate({ data: { language: next } });
  };
  const t = (key: string) => copy(lang, key);
  const navigation = [
    { href: '/', label: t('leaderboard'), icon: <Crown size={17} /> },
    { href: '/testers', label: t('testers'), icon: <ShieldCheck size={17} /> },
    ...(user?.role === 'admin' ? [{ href: '/admin', label: t('admin'), icon: <ClipboardList size={17} /> }] : []),
  ];
  return <div className="app-frame">
    <header className="topbar">
      <Link href="/" className="brand" data-testid="link-brand"><span className="brand-mark"><Swords size={19} /></span><span>SoLo<span>TIERS</span></span></Link>
      <span className="brand-caption">{t('protocol')}</span>
      <nav className="desktop-nav" aria-label={lang==='ru'?'Основная навигация':'Main navigation'}>{navigation.map(n => <Link key={n.href} href={n.href} className={`nav-link ${location === n.href || (n.href === '/' && location.startsWith('/kits/')) ? 'active' : ''}`} data-testid={`link-nav-${n.href.replace('/', 'home')}`}>{n.icon}{n.label}</Link>)}</nav>
      <div className="top-actions">
        <button className="language-switch" onClick={() => changeLanguage(lang === 'ru' ? 'en' : 'ru')} aria-label={lang==='ru'?'Переключить язык':'Toggle language'} data-testid="button-language"><Globe2 size={15} /><span>{lang.toUpperCase()}</span></button>
        {user ? <div className="session-chip"><span className="user-dot">{initials(user.username)}</span><span className="session-name">{user.username}</span><LogoutButton token={token} t={t} /></div> : <Link href="/auth" className="login-link" data-testid="link-login"><LogIn size={15} />{t('login')}</Link>}
        <button className="mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} aria-label={lang==='ru'?'Открыть навигацию':'Open navigation'} data-testid="button-mobile-menu">{mobileOpen ? <X size={20} /> : <Menu size={20} />}</button>
      </div>
    </header>
    {mobileOpen && <nav className="mobile-nav">{navigation.map(n => <Link key={n.href} onClick={() => setMobileOpen(false)} href={n.href} className="nav-link">{n.icon}{n.label}</Link>)}{!user && <Link onClick={() => setMobileOpen(false)} href="/auth" className="nav-link"><LogIn size={17} />{t('login')}</Link>}</nav>}
    <main className="main-shell"><ErrorBoundary resetKey={location}><Switch>
      <Route path="/" component={() => <OverviewPage lang={lang} t={t} />} />
      <Route path="/kits/:kit" component={() => <KitPage lang={lang} t={t} />} />
      <Route path="/players/:playerId" component={() => <PlayerPage lang={lang} t={t} />} />
      <Route path="/testers" component={() => <TestersPage lang={lang} t={t} />} />
      <Route path="/admin" component={() => <AdminPage lang={lang} t={t} token={token} userRole={user?.role} />} />
      <Route path="/auth" component={() => <AuthPage lang={lang} t={t} token={token} />} />
      <Route><NotFound t={t} lang={lang} /></Route>
    </Switch></ErrorBoundary></main>
    <footer className="footer"><span>SoLoTIERS <i>×</i> Minecraft PvP</span><span>{t('powered')}</span><span className="footer-status"><span className="status-pip" />{lang==='ru'?'API РАБОТАЕТ':'API ONLINE'}</span></footer>
    <MobileBottomNav navigation={navigation} current={location} />
  </div>;
}

function LogoutButton({ token, t }: { token?: string; t: (key: string) => string }) {
  const qc = useQueryClient();
  const logout = useLogoutAccount({ request: csrfRequest(token), mutation: { onSuccess: () => qc.invalidateQueries({ queryKey: getGetSessionQueryKey() }) } });
  return <button className="icon-button logout-button" title={t('logout')} disabled={logout.isPending||!token} onClick={() => logout.mutate()} data-testid="button-logout"><LogOut size={15} /></button>;
}

function MobileBottomNav({ navigation, current }: { navigation: {href:string;label:string;icon:ReactNode}[]; current: string }) {
  return <nav className="mobile-bottom">{navigation.slice(0, 3).map(item => <Link key={item.href} href={item.href} className={current === item.href ? 'selected' : ''} data-testid={`mobile-nav-${item.href || 'home'}`}>{item.icon}<span>{item.label}</span></Link>)}</nav>;
}

function LoadingState({ label }: { label: string }) { return <div className="state-panel" data-testid="status-loading"><div className="skeleton-bar wide" /><div className="skeleton-bar" /><div className="skeleton-bar short" /><span className="state-copy"><LoaderCircle className="spin" size={15} />{label}</span></div>; }
function ErrorState({ retry, label, lang = 'ru', retryLabel }: { retry: () => void; label: string; lang?: Language; retryLabel?: string }) { return <div className="state-panel error-state" data-testid="status-error"><span className="error-mark">!</span><div><strong>{label}</strong><p>{lang === 'ru' ? 'Сервис временно недоступен.' : 'Service is temporarily unavailable.'}</p></div><button className="button-quiet" onClick={retry} data-testid="button-retry">{retryLabel || (lang === 'ru' ? 'Повторить' : 'Retry')}</button></div>; }
function EmptyState({ title, lang = 'ru' }: { title: string; lang?: Language }) { return <div className="empty-state" data-testid="status-empty"><span className="empty-icon"><Gamepad2 size={21} /></span><strong>{title}</strong><small>{lang==='ru'?'Рейтинг обновляется после проверки результатов.':'Standings update after results are verified.'}</small></div>; }

function HeaderTitle({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" />{eyebrow}</div><h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div>;
}

function OverviewPage({ lang, t }: { lang: Language; t:(k:string)=>string }) {
  const overview = useGetOverview();
  const leaderboard = useGetOverallLeaderboard();
  const [query, setQuery] = useState('');
  const ranking = leaderboard.data || [];
  const filtered = ranking.filter(p => p.nickname.toLowerCase().includes(query.toLowerCase()));
  const liveFiltered = filtered.filter(player => !player.isDemo);
  const demoFiltered = filtered.filter(player => player.isDemo);
  const recent = overview.data?.recentHistory || [];
  if (overview.isLoading || leaderboard.isLoading) return <LoadingState label={t('loading')} />;
  if (overview.isError || leaderboard.isError) return <ErrorState lang={lang} label={lang === 'ru' ? 'Не удалось загрузить рейтинг' : 'Could not load standings'} retry={() => { overview.refetch(); leaderboard.refetch(); }} />;
  return <div className="page-content">
    <div className="hero-strip"><div className="hero-copy"><div className="eyebrow"><span className="live-badge"><span />{lang==='ru'?'АКТИВНЫЙ РЕЙТИНГ':'LIVE LADDER'}</span>{t('overview')}</div><h1>{lang==='ru'?<>Сильнейшие<br/><em>по фактам.</em></>:<>Best players<br/><em>by proof.</em></>}</h1><p>{lang === 'ru' ? 'Уровень каждого игрока подтверждён тестерами SoLoTIERS.' : 'Every player’s level is verified by SoLoTIERS testers.'}</p><div className="hero-meta"><span><Activity size={14} /> {t('verified')} {lang==='ru'?'результаты':'results'}</span><span className="hero-separator" /><span>{lang==='ru'?'СЕЗОН 01':'SEASON 01'}</span></div></div><div className="hero-art" aria-hidden="true"><div className="pixel-grid" /><div className="art-ring ring-one" /><div className="art-ring ring-two" /><div className="art-cross">+</div><div className="art-score"><small>{lang==='ru'?'ЛИДЕР':'TOP RANK'}</small><b>01</b><span>{lang==='ru'?'ПОДТВЕРЖДЕНО':'EST. VERIFIED'}</span></div><div className="art-diamond" /></div></div>
    <section className="metric-grid" aria-label={t('overview')}>
      <Metric label={t('totalPlayers')} value={overview.data?.playerCount} index="01" />
      <Metric label={t('tests')} value={overview.data?.testCount} index="02" />
      <Metric label={t('activeTesters')} value={overview.data?.testerCount} index="03" />
      <Metric label={t('demoPlayers')} value={overview.data?.demoCount} index="04" />
    </section>
    <div className="content-columns">
      <section className="panel leaderboard-panel"><div className="panel-heading"><div><div className="eyebrow">{lang==='ru'?'ОБЩИЙ / ПРОВЕРЕНО':'GLOBAL / VERIFIED'}</div><h2>{t('allPlayers')}</h2></div><label className="search-box"><Search size={15} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder={t('search')} data-testid="input-player-search" /></label></div>
        {liveFiltered.length === 0 ? <EmptyState title={t('noPlayers')} lang={lang} /> : <div className="ranking-list">{liveFiltered.map((p, index) => <PlayerRow key={p.id} player={p} rank={index + 1} t={t} />)}</div>}
        {demoFiltered.length > 0 && <div className="demo-section" data-testid="demo-player-list"><div className="demo-section-title"><span>DEMO</span>{t('demoSection')}</div><div className="ranking-list">{demoFiltered.map((p, index) => <PlayerRow key={p.id} player={p} rank={index + 1} t={t} />)}</div></div>}
        <Link href="/kits/sword" className="panel-footer-link" data-testid="link-kit-leaderboards">{lang === 'ru' ? 'Посмотреть рейтинги по режимам' : 'Browse kit standings'}<ArrowRight size={15} /></Link>
      </section>
      <aside className="side-stack">
        <section className="panel tiers-panel"><div className="panel-heading compact"><div><div className="eyebrow">{lang==='ru'?'РЕЖИМЫ':`${t('kit')} INDEX`}</div><h2>{lang === 'ru' ? 'Выбери режим' : 'Select a kit'}</h2></div><ChevronDown size={16} className="muted-icon" /></div><div className="kit-grid">{kits.map((kit, i) => <Link key={kit} href={`/kits/${kit.toLowerCase()}`} className="kit-tile" data-testid={`link-kit-${kit}`}><span className="kit-num">{String(i + 1).padStart(2, '0')}</span><span>{kit}</span><ChevronRight size={13} /></Link>)}</div></section>
        <section className="panel recent-panel"><div className="panel-heading compact"><div><div className="eyebrow">{lang==='ru'?'ЖУРНАЛ ПРОВЕРОК':'AUDIT LOG'}</div><h2>{t('recent')}</h2></div><Activity size={16} className="muted-icon" /></div>{recent.length === 0 ? <div className="mini-empty">{t('emptyHistory')}</div> : recent.slice(0, 5).map(entry => <div className="history-mini" key={entry.id}><span className={`tier-badge tier-${entry.newTier.toLowerCase()}`}>{entry.newTier}</span><div><Link href={`/players/${entry.playerId}`} className="history-nick">{entry.nickname}</Link><span className="history-change">{entry.kit} · {entry.oldTier} → {entry.newTier}</span></div><time>{formatDate(entry.occurredAt, lang)}</time></div>)}</section>
      </aside>
    </div>
  </div>;
}

function Metric({ label, value, index }: { label:string; value?:number; index:string }) {
  return <div className="metric"><span className="metric-index">{index}</span><strong data-testid={`metric-value-${index}`}>{value ?? '—'}</strong><span>{label}</span><div className="metric-rule" /></div>;
}
function PlayerRow({ player, rank, t }: { player: PlayerRanking | Player; rank: number; t:(k:string)=>string }) {
  return <Link href={`/players/${player.id}`} className="player-row" data-testid={`row-player-${player.id}`}><span className={`rank-number ${rank <= 3 ? 'rank-podium' : ''}`}>{String(rank).padStart(2, '0')}</span><span className="skin-frame"><img src={player.skinUrl} alt="" data-testid={`img-skin-${player.id}`} /></span><span className="player-main"><span className="player-name-wrap"><strong>{player.nickname}</strong>{player.isDemo && <i className="demo-tag">DEMO</i>}</span><span className="overall-tier-scroll" aria-label={t('tierDistribution')}><span className="overall-tier-grid">{kits.map(kit=><span className="overall-tier-item" key={kit} title={`${kit}: ${player.tiers[kit]}`} data-testid={`player-tier-${player.id}-${kit}`}><small>{kit}</small><i className={`tier-badge tier-${player.tiers[kit].toLowerCase()}`}>{player.tiers[kit]}</i></span>)}</span></span></span><span className="row-points">{player.points.toLocaleString()}<small> {t('points')}</small></span><ArrowRight size={15} className="row-arrow" /></Link>;
}

function TierPill({ tier }: { tier: TierType | string }) { return <span className={`tier-badge tier-${tier.toLowerCase()}`} data-testid={`tier-value-${tier}`}>{tier}</span>; }

function KitPage({ lang, t }: {lang:Language;t:(k:string)=>string}) {
  const [, params] = useRoute('/kits/:kit');
  const kitSlug = params?.kit || '';
  const kit = kits.find(k => k.toLowerCase() === kitSlug.toLowerCase());
  if (!kit) return <NotFound t={t} lang={lang} />;
  return <KitLeaderboardPage kit={kit} lang={lang} t={t} />;
}
function KitLeaderboardPage({kit, lang, t}:{kit:KitType;lang:Language;t:(k:string)=>string}) {
  const data = useGetKitLeaderboard(kit);
  if(data.isLoading) return <LoadingState label={t('loading')} />;
  if(data.isError) return <ErrorState lang={lang} label={lang==='ru'?'Не удалось загрузить рейтинг режима':'Could not load kit standings'} retry={()=>data.refetch()} />;
  const players = (data.data?.tiers || []).flatMap(bucket => bucket.players.map(player => ({player,tier:bucket.tier}))).filter(item=>item.tier!==Tier.NA).sort((a,b)=>tierWeight[a.tier]-tierWeight[b.tier]||nickOrder(a.player.nickname,b.player.nickname));
  const livePlayers=players.filter(item=>!item.player.isDemo);
  const demoPlayers=players.filter(item=>item.player.isDemo);
  return <div className="page-content"><div className="breadcrumbs"><Link href="/" data-testid="link-back-leaderboard"><ArrowLeft size={14} />{t('leaderboard')}</Link><ChevronRight size={13}/><span>{kit}</span></div><HeaderTitle eyebrow={`${lang==='ru'?'РЕЙТИНГ РЕЖИМА':'KIT LEADERBOARD'} / ${kit.toUpperCase()}`} title={`${kit} ${lang==='ru'?'рейтинг':'standings'}`} description={lang==='ru'?'Позиции отсортированы по тиру, затем по нику игрока.':'Ranked by tier, then player nickname.'} /><div className="kit-total"><span className="status-pip" />{data.data?.totalPlayers ?? livePlayers.length} {t('players')}<span className="total-divider" />10 {lang==='ru'?'уровней':'tiers'}</div>
    <TierSequence />
    <div className="panel kit-table"><div className="table-head"><span>{t('rank')}</span><span>{t('player')}</span><span>{t('kit')}</span><span>{t('points')}</span></div>
      {livePlayers.length===0 ? <EmptyState title={t('noResults')} lang={lang} /> : livePlayers.map(({player,tier},idx)=><Link href={`/players/${player.id}`} className="kit-player-row" key={player.id} data-testid={`row-kit-player-${player.id}`}><span className="rank-number">{String(idx+1).padStart(2,'0')}</span><span className="table-player"><span className="skin-frame small"><img src={player.skinUrl} alt="" /></span><strong>{player.nickname}</strong></span><TierPill tier={tier} /><span className="row-points">{player.points.toLocaleString()}</span></Link>)}
    </div>
    {demoPlayers.length>0&&<section className="demo-section demo-kit-section" data-testid="demo-kit-players"><div className="demo-section-title"><span>DEMO</span>{t('demoSection')}</div><div className="panel kit-table"><div className="table-head"><span>{t('rank')}</span><span>{t('player')}</span><span>{t('kit')}</span><span>{t('points')}</span></div>{demoPlayers.map(({player,tier},idx)=><Link href={`/players/${player.id}`} className="kit-player-row" key={player.id} data-testid={`row-demo-kit-player-${player.id}`}><span className="rank-number">{String(idx+1).padStart(2,'0')}</span><span className="table-player"><span className="skin-frame small"><img src={player.skinUrl} alt="" /></span><strong>{player.nickname}</strong><i className="demo-tag">DEMO</i></span><TierPill tier={tier} /><span className="row-points">{player.points.toLocaleString()}</span></Link>)}</div></section>}
  </div>;
}
function TierSequence() { return <div className="tier-sequence" data-testid="tier-sequence">{tiers.map(t=><span key={t} className={`tier-segment tier-${t.toLowerCase()}`}>{t}</span>)}</div>; }

function PlayerPage({lang,t}:{lang:Language;t:(k:string)=>string}) {
  const [,params]=useRoute('/players/:playerId');
  const id=Number(params?.playerId);
  const player=useGetPlayer(id,{query:{enabled:Number.isFinite(id)&&id>0,queryKey:getGetPlayerQueryKey(id)}});
  const history=useGetPlayerHistory(id,{query:{enabled:Number.isFinite(id)&&id>0,queryKey:getGetPlayerHistoryQueryKey(id)}});
  if(player.isLoading) return <LoadingState label={t('loading')} />;
  if(player.isError||!player.data) return <ErrorState lang={lang} label={lang==='ru'?'Игрок не найден':'Player not found'} retry={()=>player.refetch()} />;
  const p=player.data;
  return <div className="page-content"><div className="breadcrumbs"><Link href="/" data-testid="link-back-leaderboard"><ArrowLeft size={14}/>{t('leaderboard')}</Link><ChevronRight size={13}/><span>{p.nickname}</span></div>
    <section className="profile-hero"><div className="profile-skin"><img src={p.skinUrl} alt={`${p.nickname} Minecraft skin`} data-testid="img-profile-skin" /></div><div className="profile-identity"><div className="eyebrow"><BadgeCheck size={14}/>{lang==='ru'?'ПРОВЕРЕННЫЙ ИГРОК':'VERIFIED PLAYER'} {p.isDemo&&<i className="demo-tag">DEMO</i>}</div><h1 data-testid="text-player-nickname">{p.nickname}</h1><span className="profile-joined">{lang==='ru'?'В рейтинге с':'Ranked since'} {formatDate(p.createdAt,lang)}</span></div><div className="profile-score"><span>{t('score')}</span><strong>{p.points.toLocaleString()}</strong><small>{t('points')}</small></div></section>
    <section className="panel profile-kits"><div className="panel-heading"><div><div className="eyebrow">{lang==='ru'?'ПРОФИЛЬ СОСТЯЗАНИЙ':'COMPETITIVE PROFILE'}</div><h2>{lang==='ru'?'Результаты по режимам':'Kit standings'}</h2></div><span className="profile-count">10 {t('kit')}</span></div><TierSequence/><div className="profile-kit-grid">{kits.map((kit,i)=><Link href={`/kits/${kit.toLowerCase()}`} key={kit} className="profile-kit" data-testid={`profile-kit-${kit}`}><span><small>{String(i+1).padStart(2,'0')}</small>{kit}</span><TierPill tier={p.tiers[kit]}/></Link>)}</div></section>
    <section className="panel profile-history"><div className="panel-heading"><div><div className="eyebrow">{lang==='ru'?'ЗАПИСЬ ПРОВЕРОК':'VERIFICATION RECORD'}</div><h2>{t('history')}</h2></div><ClipboardList size={17} className="muted-icon"/></div>{history.isLoading?<LoadingState label={t('loading')}/>:history.isError?<ErrorState lang={lang} label={lang==='ru'?'История недоступна':'History unavailable'} retry={()=>history.refetch()}/>:!history.data?.length?<EmptyState title={t('emptyHistory')} lang={lang}/>:history.data.map(entry=><div className="history-entry" key={entry.id} data-testid={`history-entry-${entry.id}`}><div className="history-timeline"><span/></div><div className="history-main"><div><strong>{entry.kit}</strong><small>{lang==='ru'?'проверил':'reviewed by'} {entry.reviewer}</small></div><div className="history-tiers"><TierPill tier={entry.oldTier}/><ArrowRight size={14}/><TierPill tier={entry.newTier}/></div><time>{formatDate(entry.occurredAt,lang)}</time></div></div>)}</section>
  </div>;
}

function TestersPage({lang,t}:{lang:Language;t:(k:string)=>string}) {
  const testers=useListTesters();
  return <div className="page-content"><HeaderTitle eyebrow={lang==='ru'?'ПРОВЕРЕНО ИГРОКАМИ':'VERIFIED BY PEOPLE'} title={t('testerDirectory')} description={langText(t,'testersDesc')} />
    {testers.isLoading?<LoadingState label={t('loading')}/>:testers.isError?<ErrorState lang={lang} label={lang==='ru'?'Не удалось загрузить список тестеров':'Could not load tester directory'} retry={()=>testers.refetch()}/>:!testers.data?.length?<EmptyState title={t('noTesters')} lang={lang}/>:<div className="tester-grid">{testers.data.map((person,i)=><article className="tester-card" key={person.id} data-testid={`card-tester-${person.id}`}><div className="tester-index">{lang==='ru'?'ТЕСТЕР':'VERIFIER'} / {String(i+1).padStart(2,'0')}</div><div className="tester-avatar">{initials(person.displayName||person.username)}</div><h2>{person.displayName}</h2><span className="tester-handle">@{person.username}</span><div className="tester-card-bottom"><span><ShieldCheck size={14}/> {lang==='ru'?'ТЕСТЕР':'VERIFIED TESTER'}</span>{person.discordId&&<span className="discord-mark">{lang==='ru'?'ID ПРИВЯЗАН':'ID LINKED'}</span>}</div></article>)}</div>}
    <div className="trust-note"><ShieldCheck size={19}/><span><strong>{t('verified')}</strong><small>{t('powered')}</small></span><ExternalLink size={15}/></div>
  </div>;
}
function langText(t:(k:string)=>string,key:string) { return key==='testersDesc'?(t('testerDirectory')==='Команда проверяющих'?'Все результаты рейтинга проверяются людьми. Без автоматических оценок.':'Every result is reviewed by a person. No automated ratings.'):t(key); }

function AuthPage({lang,t,token}:{lang:Language;t:(k:string)=>string;token?:string}) {
  const qc=useQueryClient();
  const [mode,setMode]=useState<'login'|'register'>('login');
  const [username,setUsername]=useState(''); const [password,setPassword]=useState(''); const [error,setError]=useState('');
  const request=csrfRequest(token);
  const register=useRegisterAccount({request,mutation:{onSuccess:()=>{setError('');qc.invalidateQueries({queryKey:getGetSessionQueryKey()});}}});
  const login=useLoginAccount({request,mutation:{onSuccess:()=>{setError('');qc.invalidateQueries({queryKey:getGetSessionQueryKey()});}}});
  const submit=(e:FormEvent)=>{e.preventDefault();setError('');if(mode==='register')register.mutate({data:{username,password,language:lang}},{onError:(err)=>setError(err.message)});else login.mutate({data:{username,password}},{onError:(err)=>setError(err.message)});};
  const pending=register.isPending||login.isPending;
  return <div className="auth-layout"><div className="auth-aside"><div className="eyebrow">{lang==='ru'?'АККАУНТ SOLOTIERS':'SOLOTIERS ACCOUNT'}</div><h1>{lang==='ru'?<>Каждый матч<br/><em>имеет значение.</em></>:<>Make every<br/><em>match count.</em></>}</h1><p>{lang==='ru'?'Единый аккаунт для участия в проверенных PvP-рейтингах.':'One account for verified PvP standings.'}</p><div className="auth-aside-mark"><Swords size={44}/></div></div><section className="auth-card"><div className="eyebrow">{t('registered')}</div><h2>{mode==='login'?t('login'):t('signup')}</h2><div className="auth-tabs"><button className={mode==='login'?'selected':''} onClick={()=>setMode('login')} data-testid="button-auth-login">{t('login')}</button><button className={mode==='register'?'selected':''} onClick={()=>setMode('register')} data-testid="button-auth-register">{t('signup')}</button></div><form onSubmit={submit}><label>{t('username')}<input autoComplete="username" value={username} onChange={e=>setUsername(e.target.value)} minLength={3} maxLength={24} required data-testid="input-username"/></label><label>{t('password')}<input type="password" autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} minLength={mode==='register'?10:1} maxLength={128} required data-testid="input-password"/></label>{error&&<div className="form-error" data-testid="status-auth-error">{error}</div>}<button className="button-primary full-width" type="submit" disabled={pending||!token} data-testid="button-auth-submit">{pending?<LoaderCircle className="spin" size={16}/>:mode==='login'?t('login'):t('create')}<ArrowRight size={16}/></button></form><p className="form-caption">{lang==='ru'?'Регистрация доступна игрокам и тестерам.':'Accounts are for players and testers.'}</p></section></div>;
}

function AdminPage({lang,t,token,userRole}:{lang:Language;t:(k:string)=>string;token?:string;userRole?:string}) {
  const qc=useQueryClient();
  const request=csrfRequest(token);
  const users=useListAdminUsers({query:{enabled:userRole==='admin',queryKey:getListAdminUsersQueryKey()}});
  const testers=useListTesters({query:{enabled:userRole==='admin',queryKey:getListTestersQueryKey()}});
  const settings=useGetSettings({query:{enabled:userRole==='admin',queryKey:getGetSettingsQueryKey()}});
  const [nickname,setNickname]=useState('');const [isDemo,setIsDemo]=useState(false);const [kit,setKit]=useState<KitType>(Kit.Sword);const [tier,setTier]=useState<TierType>(Tier.HT1);
  const [discordId,setDiscordId]=useState('');const [playerId,setPlayerId]=useState('');const [siteName,setSiteName]=useState('SoLoTIERS');const [notice,setNotice]=useState('');
  const [defaultLanguage,setDefaultLanguage]=useState<Language>(lang);const [editNickname,setEditNickname]=useState('');
  const settingsInitialized=useRef(false);
  const roleText=(role:string)=>{
    const labels:Record<string,string>=lang==='ru'?{admin:'Администратор',tester:'Тестер',user:'Игрок'}:{admin:'Admin',tester:'Tester',user:'Player'};
    return labels[role]||role;
  };
  useEffect(()=>{if(settings.data&&!settingsInitialized.current){settingsInitialized.current=true;setSiteName(settings.data.siteName);setDefaultLanguage(settings.data.defaultLanguage);}},[settings.data]);
  const invalidateAll=()=>{qc.invalidateQueries({queryKey:getGetOverviewQueryKey()});qc.invalidateQueries({queryKey:getGetOverallLeaderboardQueryKey()});kits.forEach(k=>qc.invalidateQueries({queryKey:getGetKitLeaderboardQueryKey(k)}));qc.invalidateQueries({queryKey:getListPlayersQueryKey()});qc.invalidateQueries({queryKey:getListTestersQueryKey()});qc.invalidateQueries({queryKey:getListAdminUsersQueryKey()});qc.invalidateQueries({queryKey:getGetSettingsQueryKey()});const id=Number(playerId);if(id>0){qc.invalidateQueries({queryKey:getGetPlayerQueryKey(id)});qc.invalidateQueries({queryKey:getGetPlayerHistoryQueryKey(id)});}setNotice(lang==='ru'?'Изменения сохранены':'Changes saved');};
  const createPlayer=useCreatePlayer({request,mutation:{onSuccess:()=>{invalidateAll();setNickname('');setNotice(lang==='ru'?'Игрок добавлен':'Player added');}}});
  const updatePlayer=useUpdatePlayer({request,mutation:{onSuccess:invalidateAll}});
  const deletePlayer=useDeletePlayer({request,mutation:{onSuccess:invalidateAll}});
  const updateRole=useUpdateUserRole({request,mutation:{onSuccess:invalidateAll}});
  const addTester=useAddTester({request,mutation:{onSuccess:invalidateAll}});
  const removeTester=useRemoveTester({request,mutation:{onSuccess:invalidateAll}});
  const updateSettings=useUpdateSettings({request,mutation:{onSuccess:invalidateAll}});
  const changeTier=useChangePlayerTier({request,mutation:{onSuccess:invalidateAll}});
  const adminError=users.isError||testers.isError||settings.isError;
  const mutationError=createPlayer.isError||updatePlayer.isError||deletePlayer.isError||updateRole.isError||addTester.isError||removeTester.isError||updateSettings.isError||changeTier.isError;
  if(userRole!=='admin') return <div className="restricted"><div className="restricted-stamp"><ShieldCheck size={26}/></div><div className="eyebrow">{t('access')}</div><h1>{t('admin')}</h1><p>{t('adminOnly')}</p><Link href="/auth" className="button-primary" data-testid="link-admin-login"><LogIn size={15}/>{t('login')}</Link></div>;
  const run=(fn:()=>void)=>{setNotice('');fn();};
  return <div className="page-content"><HeaderTitle eyebrow={lang==='ru'?'ПАНЕЛЬ АДМИНИСТРАТОРА / ДОСТУП ПОДТВЕРЖДЁН':'ADMIN CONSOLE / ACCESS VERIFIED'} title={t('admin')} description={lang==='ru'?'Управление реестром игроков, тестерами и подтверждёнными результатами.':'Manage players, testers and verified results.'} />
    {adminError&&<ErrorState lang={lang} label={lang==='ru'?'Не удалось загрузить панель':'Could not load management data'} retry={()=>{users.refetch();testers.refetch();settings.refetch();}}/>}
    {mutationError&&<div className="form-error" role="alert" data-testid="status-admin-error">{lang==='ru'?'Не удалось сохранить изменения. Проверьте данные и попробуйте снова.':'Could not save changes. Check the details and try again.'}</div>}
    {notice&&<div className="success-notice" data-testid="status-admin-notice"><BadgeCheck size={16}/>{notice}</div>}
    <div className="admin-layout"><div className="admin-main">
      <section className="panel admin-section"><div className="panel-heading"><div><div className="eyebrow">{lang==='ru'?'РЕЕСТР ИГРОКОВ':'PLAYER REGISTRY'}</div><h2>{t('createPlayer')}</h2></div><UserRound size={17}/></div><form className="admin-form" onSubmit={e=>{e.preventDefault();run(()=>createPlayer.mutate({data:{nickname,isDemo}}));}}><label>{t('nickname')}<input value={nickname} onChange={e=>setNickname(e.target.value)} minLength={3} maxLength={16} required data-testid="input-player-nickname"/></label><label className="checkbox-label"><input type="checkbox" checked={isDemo} onChange={e=>setIsDemo(e.target.checked)} data-testid="input-player-demo"/> DEMO</label><button className="button-primary" disabled={createPlayer.isPending||!token} data-testid="button-create-player">{t('create')}<ArrowRight size={15}/></button></form><p className="admin-footnote">{lang==='ru'?'Профиль появится в рейтинге после создания. Discord ID привязывается отдельно при проверке.':'The player profile appears after creation. Discord IDs are linked separately during verification.'}</p></section>
      <section className="panel admin-section"><div className="panel-heading"><div><div className="eyebrow">{lang==='ru'?'ПРОФИЛЬ ИГРОКА':'PLAYER RECORD'}</div><h2>{lang==='ru'?'Обновить профиль':'Edit player profile'}</h2></div><UserRound size={17}/></div><form className="admin-form two-col" onSubmit={e=>{e.preventDefault();const id=Number(playerId);if(id>0&&editNickname)run(()=>updatePlayer.mutate({playerId:id,data:{nickname:editNickname}}));}}><label>{lang==='ru'?'ID игрока':'Player ID'}<input type="number" value={playerId} onChange={e=>setPlayerId(e.target.value)} required data-testid="input-edit-player-id"/></label><label>{t('nickname')}<input value={editNickname} onChange={e=>setEditNickname(e.target.value)} minLength={3} maxLength={16} required data-testid="input-edit-nickname"/></label><button className="button-quiet" disabled={updatePlayer.isPending||!token} data-testid="button-update-player">{t('save')}<ArrowRight size={15}/></button></form><p className="admin-footnote">{lang==='ru'?'Привязка Discord изменяется только через проверку.':'Discord mapping can only be changed through verification.'}</p></section>
      <section className="panel admin-section" data-testid="status-discord-api"><div className="panel-heading"><div><div className="eyebrow">{lang==='ru'?'DISCORD API / ГОТОВО':'DISCORD API / READY'}</div><h2>Discord API</h2></div><ShieldCheck size={17}/></div><p className="admin-footnote">{lang==='ru'?'Подготовлены защищённые API-методы для проверки связи игрока и сохранения результатов. API-ключ остаётся на сервере в Replit Secrets; бот пока не подключён.':'Protected API routes are ready for player verification and tier results. The key stays server-side in Replit Secrets; the bot is not connected yet.'}</p></section>
      <section className="panel admin-section"><div className="panel-heading"><div><div className="eyebrow">{lang==='ru'?'НАСТРОЙКИ САЙТА':'SITE CONFIGURATION'}</div><h2>{t('settings')}</h2></div><Globe2 size={17}/></div><form className="admin-form two-col" onSubmit={e=>{e.preventDefault();run(()=>updateSettings.mutate({data:{siteName,defaultLanguage}}));}}><label>{t('siteName')}<input value={siteName} onChange={e=>setSiteName(e.target.value)} minLength={1} maxLength={48} data-testid="input-site-name"/></label><label>{t('defaultLanguage')}<select value={defaultLanguage} onChange={e=>setDefaultLanguage(e.target.value as Language)} data-testid="select-default-language"><option value="ru">Русский</option><option value="en">English</option></select></label><button className="button-quiet" disabled={updateSettings.isPending||!token} data-testid="button-save-settings">{t('save')}<ArrowRight size={15}/></button></form><div className="admin-footnote">{settings.data?.siteName || 'SoLoTIERS'} · {t('language')}: {settings.data?.defaultLanguage || lang}</div></section>
    </div><aside className="admin-side">
      <section className="panel admin-section"><div className="panel-heading compact"><div><div className="eyebrow">{lang==='ru'?'ДОСТУП ПОЛЬЗОВАТЕЛЕЙ':'USER ACCESS'}</div><h2>{t('users')}</h2></div><Users size={16}/></div>{users.isLoading?<LoadingState label={t('loading')}/>:users.data?.map(account=><div className="admin-user" key={account.id} data-testid={`admin-user-${account.id}`}><div className="user-dot">{initials(account.username)}</div><div className="admin-user-name"><strong>{account.username}</strong><small>{roleText(account.role)}</small></div><select disabled={!token} value={account.role} onChange={e=>updateRole.mutate({userId:account.id,data:{role:e.target.value as 'admin'|'tester'|'user'}})} aria-label={lang==='ru'?`Роль для ${account.username}`:`Role for ${account.username}`} data-testid={`select-role-${account.id}`}><option value="user">{roleText('user')}</option><option value="tester">{roleText('tester')}</option><option value="admin">{roleText('admin')}</option></select></div>)}</section>
      <section className="panel admin-section"><div className="panel-heading compact"><div><div className="eyebrow">{lang==='ru'?'СПИСОК ТЕСТЕРОВ':'TESTER ROSTER'}</div><h2>{t('testers')}</h2></div><ShieldCheck size={16}/></div><form className="stacked-form" onSubmit={e=>{e.preventDefault();const uid=Number(playerId);if(uid>0)addTester.mutate({data:{userId:uid,discordId:discordId||null}});}}><label>{lang==='ru'?'ID пользователя':'User ID'}<input type="number" value={playerId} onChange={e=>setPlayerId(e.target.value)} required data-testid="input-tester-user-id"/></label><label>{t('discordId')}<input value={discordId} onChange={e=>setDiscordId(e.target.value)} data-testid="input-tester-discord"/></label><button className="button-quiet" disabled={addTester.isPending||!token} data-testid="button-add-tester">{t('addTester')}<ArrowRight size={14}/></button></form>{testers.data?.map(person=><div className="admin-user tester-admin" key={person.id}><div className="user-dot">{initials(person.displayName||person.username)}</div><div className="admin-user-name"><strong>{person.displayName}</strong><small>{person.discordId||person.username}</small></div><button className="icon-button danger-icon" disabled={!token} onClick={()=>{if(window.confirm(lang==='ru'?'Удалить тестера?':'Remove this tester?'))removeTester.mutate({userId:person.id});}} aria-label={lang==='ru'?'Удалить тестера':'Remove tester'} data-testid={`button-remove-tester-${person.id}`}><X size={15}/></button></div>)}</section>
      <section className="panel admin-section"><div className="panel-heading compact"><div><div className="eyebrow">{lang==='ru'?'ИЗМЕНИТЬ ТИР':'TIER OVERRIDE'}</div><h2>{lang==='ru'?'Изменить тир':'Change tier'}</h2></div><Swords size={16}/></div><form className="stacked-form" onSubmit={e=>{e.preventDefault();const id=Number(playerId);if(id>0)changeTier.mutate({playerId:id,kit,data:{tier}});}}><label>{lang==='ru'?'ID игрока':'Player ID'}<input type="number" value={playerId} onChange={e=>setPlayerId(e.target.value)} required data-testid="input-tier-player-id"/></label><label>{t('kit')}<select value={kit} onChange={e=>setKit(e.target.value as KitType)} data-testid="select-tier-kit">{kits.map(k=><option key={k}>{k}</option>)}</select></label><label>{t('tier')}<select value={tier} onChange={e=>setTier(e.target.value as TierType)} data-testid="select-tier-value">{[...tiers,Tier.NA].map(x=><option key={x}>{x}</option>)}</select></label><button className="button-quiet" disabled={changeTier.isPending||!token} data-testid="button-change-tier">{t('save')}<ArrowRight size={14}/></button></form></section>
      <section className="panel admin-section"><div className="panel-heading compact"><div><div className="eyebrow">{lang==='ru'?'УПРАВЛЕНИЕ ИГРОКАМИ':'PLAYER MAINTENANCE'}</div><h2>{lang==='ru'?'Удалить игрока':'Remove player'}</h2></div><X size={16}/></div><form className="admin-form" onSubmit={e=>{e.preventDefault();const id=Number(playerId);if(id>0&&window.confirm(lang==='ru'?'Удалить запись игрока?':'Delete this player record?'))deletePlayer.mutate({playerId:id});}}><label>{lang==='ru'?'ID игрока':'Player ID'}<input type="number" value={playerId} onChange={e=>setPlayerId(e.target.value)} required data-testid="input-delete-player-id"/></label><button className="button-danger" disabled={deletePlayer.isPending||!token} data-testid="button-delete-player">{lang==='ru'?'Удалить игрока':'Delete player'}</button></form></section>
    </aside></div>
  </div>;
}

function NotFound({t,lang}:{t:(k:string)=>string;lang:Language}) { return <div className="not-found"><div className="eyebrow">404 / {lang==='ru'?'НЕ НАЙДЕНО':'NO MATCH'}</div><h1>{lang==='ru'?<>Потерялись<br/><em>на арене.</em></>:<>Lost in<br/><em>the arena.</em></>}</h1><p>{t('noResults')}</p><Link href="/" className="button-primary" data-testid="link-notfound-home"><ArrowLeft size={15}/>{t('leaderboard')}</Link></div>; }

export default App;
